self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d8ef7d5718eff4e8c3abf045c881b94b",
    "url": "/index.html"
  },
  {
    "revision": "6c6baa242fe116bdb19b",
    "url": "/static/css/2.48db8b0f.chunk.css"
  },
  {
    "revision": "b4ee9ae04683853d9a55",
    "url": "/static/css/main.eed1b2c4.chunk.css"
  },
  {
    "revision": "6c6baa242fe116bdb19b",
    "url": "/static/js/2.861fdac3.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "/static/js/2.861fdac3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b4ee9ae04683853d9a55",
    "url": "/static/js/main.528468f6.chunk.js"
  },
  {
    "revision": "05567713dd457e4a83d8",
    "url": "/static/js/runtime-main.676014ac.js"
  },
  {
    "revision": "142c8c7ffbd4f05b42de3a347ada6a45",
    "url": "/static/media/Starlink_Logo.142c8c7f.svg"
  },
  {
    "revision": "353608ac98fb954404e470823f166b5f",
    "url": "/static/media/satellite1.353608ac.png"
  }
]);